
  globalThis.Event = globalThis.DenoEvent
  